#include <windows.h>
#include <gl/Gl.h>
#include <GL/glut.h>
#include <cmath>

int ww=700;
int wh=700;
int first=0;

struct Point {
    GLint x;
    GLint y;
};

struct Color {
    GLfloat r;
    GLfloat g;
    GLfloat b;
};

void display()
{
    glClearColor(1.0,1.0,0.0,0.0);
    glColor3f(1.0,0.0,0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}
typedef struct{
   float x;
   float y;
 }Point2D;
Point2D p1,p2,p3,p4,p5;

void drawpolygon(Point2D pt1,Point2D pt2,Point2D pt3,Point2D pt4,Point2D pt5)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_LINE_LOOP);
            glVertex2i(pt1.x,pt1.y);
            glVertex2i(pt2.x,pt2.y);
            glVertex2i(pt3.x,pt3.y);
            glVertex2i(pt4.x,pt4.y);
            glVertex2i(pt5.x,pt5.y);
        glEnd();
        glFlush();
}

Color getPixelColor(GLint x, GLint y) {
    Color color;
    glReadPixels(x, y, 1, 1, GL_RGB, GL_FLOAT, &color);
    return color;
}

void setPixelColor(GLint x, GLint y, Color color) {
    glColor3f(color.r, color.g, color.b);
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
    glFlush();
}

void floodFill(GLint x, GLint y, Color oldColor, Color newColor) {
    Color color;
    color = getPixelColor(x, y);

    if(color.r == oldColor.r && color.g == oldColor.g && color.b == oldColor.b)
    {
        setPixelColor(x, y, newColor);
        floodFill(x+1, y, oldColor, newColor);
        floodFill(x, y+1, oldColor, newColor);
        floodFill(x-1, y, oldColor, newColor);
        floodFill(x, y-1, oldColor, newColor);
    }
    return;
}
int c=0;
void mouse(int btn, int state,int x,int y)
{
    c++;
    if(btn==GLUT_LEFT_BUTTON)
        if(state==GLUT_DOWN)
        {
            switch(first)
            {
                case 0:
                    p1.x=x;
                    p1.y=(wh-y);
                    first=1;
                    break;

                case 1:
                    p2.x=x;
                    p2.y=wh-y;
                    first=2;
                    break;
                case 2:
                    p3.x=x;
                    p3.y=wh-y;
                    first=3;
                    break;
                case 3:
                    p4.x=x;
                    p4.y=wh-y;
                    first=4;
                    break;
                case 4:
                    p5.x=x;
                    p5.y=wh-y;
                    first=0;
                    drawpolygon(p1,p2,p3,p4,p5);
                    Color newColor = {1.0f, 0.0f, 0.0f};
                    Color oldColor = {1.0f, 1.0f, 0.0f};
                    floodFill((int)(p1.x+p2.x+p3.x+p4.x+p5.x)/5, (int)(p1.y+p2.y+p3.y+p4.y+p5.y)/5, oldColor, newColor);
                    break;
            }
        }

}

int main (int argc, char** argv){
    glutInit(&argc, argv);
    glutInitWindowSize(ww,wh);
    glutCreateWindow("demo");
    gluOrtho2D(0.0,(GLdouble)ww,0.0,(GLdouble)wh);
    glutDisplayFunc(display);
    glutMouseFunc(mouse);

    glutMainLoop();
    return 0;
}
