#include <windows.h>
#include <gl/Gl.h>
#include <GL/glut.h>
#include <cmath>

int windowWidth=700;
int windowHeight=700;
int noOfPoints=0;
int currentNumberPoints = 0;

struct Point {
    GLint x;
    GLint y;
};

struct Color {
    GLfloat r;
    GLfloat g;
    GLfloat b;
};

void display()
{
    glClearColor(1.0,1.0,1.0,0.0);
    glColor3f(0.0,0.0,0.0);
    glClear(GL_COLOR_BUFFER_BIT);
    glFlush();
}

typedef struct{
   float x;
   float y;
 }Points;
Points point1,point2,point3,point4,point5;

void drawpolygon(Points point1,Points point2,Points point3,Points point4,Points point5)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_LINE_LOOP);
            glVertex2i(point1.x,point1.y);
            glVertex2i(point2.x,point2.y);
            glVertex2i(point3.x,point3.y);
            glVertex2i(point4.x,point4.y);
            glVertex2i(point5.x,point5.y);
        glEnd();
        glFlush();
}

Color getPixelColor(GLint x, GLint y) {
    Color color;
    glReadPixels(x, y, 1, 1, GL_RGB, GL_FLOAT, &color);
    return color;
}

void setPixelColor(GLint x, GLint y, Color color) {
    glColor3f(color.r, color.g, color.b);
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
    glFlush();
}

void BoundaryFill(GLint x, GLint y, Color fillColor, Color boundaryColor) {
    Color color;
    color = getPixelColor(x, y);

    if((color.r != boundaryColor.r || color.b != boundaryColor.b || color.g != boundaryColor.g)&&(
     color.r != fillColor.r || color.b != fillColor.b || color.g != fillColor.g))
    {
        setPixelColor(x, y, fillColor);
        BoundaryFill(x + 1, y, fillColor, boundaryColor);
        BoundaryFill(x, y + 1, fillColor, boundaryColor);
        BoundaryFill(x - 1, y, fillColor, boundaryColor);
        BoundaryFill(x, y - 1, fillColor, boundaryColor);
    }
    return;
}



void myMouseFunc( int button, int state, int x, int y )
{
    currentNumberPoints++;

    if ( button==GLUT_LEFT_BUTTON && state == GLUT_DOWN ) {

       switch(noOfPoints)
            {
                case 0:
                    point1.x = x;
                    point1.y =(windowHeight-y);
                    noOfPoints = 1;
                    break;

                case 1:
                    point2.x=x;
                    point2.y=windowHeight-y;
                    noOfPoints=2;
                    break;
                case 2:
                    point3.x=x;
                    point3.y=windowHeight-y;
                    noOfPoints=3;
                    break;
                case 3:
                    point4.x=x;
                    point4.y=windowHeight-y;
                    noOfPoints=4;
                    break;
                case 4:
                    point5.x = x;
                    point5.y = windowHeight-y;
                    noOfPoints = 0;
                    drawpolygon(point1,point2,point3,point4,point5);
                    Color fillColor = {0.0f, 0.0f, 0.0f};
                    Color boundaryColor = {1.0f, 1.0f, 1.0f};
                    BoundaryFill((int)(point1.x+point2.x+point3.x+point4.x+point5.x)/5, (int)(point1.y+point2.y+point3.y+point4.y+point5.y)/5,fillColor, fillColor);
                    break;
            }

        }

}

int main (int argc, char** argv){
    glutInit(&argc, argv);
    glutInitWindowSize(windowWidth,windowHeight);
    glutCreateWindow("BoundaryFill_IIT2018031");
    gluOrtho2D(0.0,(GLdouble)windowWidth,0.0,(GLdouble)windowHeight);

    glutDisplayFunc(display);
    glutMouseFunc(myMouseFunc);

    glutMainLoop();
    return 0;
}
