#include<bits/stdc++.h>
#include<windows.h>
#include <GL/glut.h>
using namespace std;

int A1, B1, A2, B2;

void drawPoint(int A, int B) {
	glBegin(GL_POINTS);
	    glVertex2i(A, B);
	glEnd();
}

void draw_line(int A1, int A2, int B1, int B2) {
	int error;
	int incrementX, incrementY, tmpinc1, tmpinc2;

	int dx = A2-A1;
	int dy = B2-B1;

	if (dx < 0){
        dx = -dx;
    }
	if (dy < 0){
        dy = -dy;
    }


	if (A2 < A1){
		incrementX = -1;
	}
	else{
		incrementX = 1;
	}

	if (B2 < B1){
		incrementY = -1;
	}
	else{
		incrementY = 1;
	}


	int x = A1;
	int y = B1;
	if (dx > dy) {
		drawPoint(x, y);
		error = 2 * dy-dx;
		tmpinc1 = 2*(dy-dx);
		tmpinc2 = 2*dy;
		for (int i=0; i<dx; i++) {
			if (error >= 0) {
				y += incrementY;
				error += tmpinc1;
			}
			else
				error += tmpinc2;
			x += incrementX;
			drawPoint(x, y);
		}

	}
	else {
		drawPoint(x, y);
		error = 2*dx-dy;
		tmpinc1 = 2*(dx-dy);
		tmpinc2 = 2*dx;
		for (int i=0; i<dy; i++) {
			if (error >= 0) {
				x += incrementX;
				error += tmpinc1;
			}
			else
				error += tmpinc2;
			y += incrementY;
			drawPoint(x, y);
		}
	}
}

void initWindow() {
	glClear(GL_COLOR_BUFFER_BIT);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glMatrixMode(GL_PROJECTION);
	gluOrtho2D(-400,400,-400,400);
}

void display() {
    glClear (GL_COLOR_BUFFER_BIT);
	    draw_line(A1, A2, B1, B2);
	glFlush();
}



int main(int argc, char **argv) {

    cout << "\"Line drawn in the four Quadrants Plane \"\n";
	cout << "Enter the value of Initial Point:\n";
    cout << "Enter the value of A1: ";
    cin >> A1;
    cout << "Enter the value of B1: ";
    cin >> B1;

    cout << "Enter the value of End Point:\n";
    cout << "Enter the value of A2: ";
    cin >> A2;
    cout << "Enter the value of B2: ";
    cin >> B2;

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(800, 800);
	glutInitWindowPosition(100, 100);
	glutCreateWindow("IIT2018031 Bresenham Algorithm for Line Drawing");
	initWindow();
	glutDisplayFunc(display);
	glutMainLoop();
    return 0;
}
